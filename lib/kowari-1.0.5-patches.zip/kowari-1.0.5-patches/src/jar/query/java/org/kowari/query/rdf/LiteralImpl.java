
/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is the Kowari Metadata Store.
 *
 * The Initial Developer of the Original Code is Plugged In Software Pty
 * Ltd (http://www.pisoftware.com, mailto:info@pisoftware.com). Portions
 * created by Plugged In Software Pty Ltd are Copyright (C) 2001,2002
 * Plugged In Software Pty Ltd. All Rights Reserved.
 *
 * Contributor(s): N/A.
 *
 * [NOTE: The text of this Exhibit A may differ slightly from the text
 * of the notices in the Source Code files of the Original Code. You
 * should use the text of this Exhibit A rather than the text found in the
 * Original Code Source Code for Your Modifications.]
 *
 */

package org.kowari.query.rdf;


// Java 2 standard packages
import java.io.*;
import java.net.URI;
import java.util.*;

// Third party packages
import org.jrdf.graph.*;  // JRDF

// Locally written packages
import org.kowari.query.ConstraintElement;
import org.kowari.query.Value;

/**
 * An RDF literal node.
 *
 * @created 2001-08-13
 *
 * @author <a href="http://staff.pisoftware.com/raboczi">Simon Raboczi</a>
 *
 * @version $Revision: 1.1 $
 *
 * @modified $Date: 2005/10/28 20:17:52 $ by $Author: cwilper $
 *
 * @maintenanceAuthor $Author: cwilper $
 *
 * @copyright &copy;2001-2003
 *   <a href="http://www.pisoftware.com/">Plugged In Software Pty Ltd</a>
 *
 * @licence <a href="{@docRoot}/../../LICENCE">Mozilla Public License v1.1</a>
 */
public class LiteralImpl extends AbstractLiteral implements Comparable,
    Serializable, Value {

  /**
   * Allow newer compiled version of the stub to operate when changes
   * have not occurred with the class.
   * NOTE : update this serialVersionUID when a method or a public member is
   * deleted.
   */
  static final long serialVersionUID = 3123944034259700724L;

  //
  // Constructors
  //

  /**
   * Construct a fully general literal.
   *
   * @param lexicalForm  the text part of the literal
   * @param language  the language code, possibly the empty string or
   *                  <code>null</code> for an untyped or datatyped literal
   * @param datatype  the URI for a datatyped literal, or <code>null</code> for
   *                  an untyped literal or a literal with a language code
   * @throws IllegalArgumentException if <var>lexicalForm</var> is
   *                                  <code>null</code> or neither
   *                                  <var>language</var> or
   *                                  <var>datatype</var> are <code>null</code>
   */
  public LiteralImpl(String lexicalForm, String language, URI datatype) {

    // Validate "lexicalForm" parameter
    if (lexicalForm == null) {
      throw new IllegalArgumentException("Null \"lexicalForm\" parameter");
    }

    // Validate "language" parameter
    if (language != null && datatype != null) {
      throw new IllegalArgumentException(
          "Literal has both a language code and a datatype"
      );
    }

    // Initialize fields
    this.lexicalForm = lexicalForm;
    this.language    = language;
    this.datatypeURI = datatype;
  }

  /**
   * Construct an untyped literal with no language.
   *
   * @param string  the untyped literal text
   * @throws IllegalArgumentException if <var>text</var> is <code>null</code>
   */
  public LiteralImpl(String string) {
    this(string, null, null);
  }

  /**
   * Construct an <code>xsd:dateTime</code> literal.
   *
   * Beware that although this is constructed from a Java {@link Date}
   * parameter, the datatype of the created literal is not
   * <code>xsd:date</code>.
   *
   * @param date  the date value of the literal
   */
  public LiteralImpl(Date date) {
    this(XSD.getLexicalForm(date), null, XSD.DATE_TIME_URI);
  }

  /**
   * Construct an <code>xsd:double</code> literal.
   *
   * @param value  the numerical value of the literal
   */
  public LiteralImpl(double value) {
    this(Double.toString(value), null, XSD.DOUBLE_URI);
  }

  /**
   * Construct a literal with no content.
   *
   * This only exists to support deserialization; it's the only way to create
   * an instance of this class in an invalid state ({@link #lexicalForm} is
   * <code>null</code>).
   *
   * @deprecated This method should never be called in source code.
   */
  protected LiteralImpl() {
    // null implementation
  }

  //
  // Methods implementing the RDFLiteral interface
  //

  /**
   * Returns a copy of itself.
   *
   * @return a copy of itself.
   */
  public Object clone() {
    try {
      return super.clone();
    }
    catch (CloneNotSupportedException e) {
      // Should never happen
      throw new InternalError(e.toString());
    }
  }

  //
  // Methods implementing the Comparable interface
  //

  /**
   * Comparison is by the <var>text</var> property.
   *
   * @param object PARAMETER TO DO
   * @return RETURNED VALUE TO DO
   */
  public int compareTo(java.lang.Object object) {

    if (object instanceof BlankNode) {

      return 1;
    }

    if (object instanceof URIReference) {

      return 1;
    }
    else if (object instanceof Literal) {

      Literal literal = (Literal) object;

      return lexicalForm.compareTo(literal.getLexicalForm());
    }
    else {

      throw new ClassCastException("Not an RDF node");
    }
  }
}
